window.screenOrientation = "sensor_landscape", 
window.CANNON = loadLib("libs/cannon.js"), 
loadLib("libs/laya.core.js"), 
loadLib("libs/laya.ui.js"), 
loadLib("libs/laya.d3.js"), 
loadLib("libs/cannon.js"), 
loadLib("libs/base64.min.js"),
loadLib("libs/laya.d3.js"), 
loadLib("js/bundle_.js");